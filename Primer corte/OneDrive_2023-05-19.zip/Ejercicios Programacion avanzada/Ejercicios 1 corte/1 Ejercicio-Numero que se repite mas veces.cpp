#include<iostream>
//En primer lugar creamos una funcion en donde vamos a ingresar las variables y va estar el poceso el pograma
void(int numero_M=0,int repeiione=0,int contador=1,int vector[i]){
	// le pedimos al usuario que dijite los numeros 
cout<< "ingrese los numeros para determinar cual numero se repite mas veces: "<<endl;
//Los guardamos en el vector
cin>>vector[i];
//Hacemos un for anidado para recorrer el vector y ir comparando un numero con otro
for(int i; i<n-1; i++){
	for(int j; j<n ;j++){
	//desarrollamos el contador
	if (contador>repeticiones){
		
		
	repeticiones=contador;
	numero_M=vecor[i];
	}
	
	
	
	}
	//se impime el resultado
	cout<<"el numero que mas se epite es: "<<numero_M<<endl;
    cou<<"y aparece: "<<repeticiones<<"veces";
}
}

int main(){
	//para imprimir la funcion 
	cout<<(void(int numero_M=0, repeiione=0, contador=0, n=7, vector[i]);
	
	}
